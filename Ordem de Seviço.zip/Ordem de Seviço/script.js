// Função de login
document.getElementById('loginButton').addEventListener('click', () => {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Verificar se o nome de usuário e senha estão corretos (exemplo simples)
    if (username === 'Pinheiro.iec' && password === '506505170') {
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('appScreen').style.display = 'block';
    } else {
        alert('Nome de usuário ou senha incorretos!');
    }
});

// Adicionar ordens de serviço
document.getElementById('submitOrder').addEventListener('click', () => {
    const service = document.getElementById('service').value;
    const responsible = document.getElementById('responsible').value;
    const hours = document.getElementById('hours').value;
    const tasks = document.getElementById('tasks').value;
    const materials = document.getElementById('materials').value;
    const deadline = document.getElementById('deadline').value;

    if (service && responsible && hours && tasks && materials && deadline) {
        const orderList = document.getElementById('orderList');
        const listItem = document.createElement('li');
        listItem.textContent = `Serviço: ${service}, Responsável: ${responsible}, Horas: ${hours}, Trabalhos: ${tasks}, Materiais: ${materials}, Prazo: ${deadline}`;
        orderList.appendChild(listItem);

        document.getElementById('orderForm').reset();
    } else {
        alert('Por favor, preencha todos os campos!');
    }
});